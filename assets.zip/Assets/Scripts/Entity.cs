﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
 using System.Collections.Generic;
[Serializable]
public class Entity {
    public Stats s = new Stats();
    public List<Stats> equip = new List<Stats>();
    public int cost () {
        return s.worth();
    }

}
