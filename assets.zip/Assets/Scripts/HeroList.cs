using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class HeroList {

    public static Entity create_mage_fighter(int str) {
        Entity e = new Entity();
        e.s.speed = 3;
        e.s.magic = 3;
        e.s.exp.increase(str * 2);
        e.s.sprite = "newchars_0";
        e.s.title = "Mage Fighter";
        Stats staff = new Stats();
        staff.type = TYPE.Staff;
        staff.sprite = "newchars_36"; //newchars_364 is the sword
        e.equip.Add(staff);
        return e;
    }
    public static Entity create_sword_fighter(int str) {
        Entity e = new Entity();
        e.s.speed = 3;
        e.s.strength = 3;
        e.s.exp.increase(str * 2);
        e.s.sprite = "newchars_0";
        e.s.title = "Sword Fighter";
        Stats sword = new Stats();
        sword.range = 1.2f;
        sword.type = TYPE.Sword;
        sword.sprite = "newchars_364"; //newchars_364 is the sword
        e.equip.Add(sword);
        return e;
    }
}