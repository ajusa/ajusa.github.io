using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
[Serializable]
public class Experience {
    public int amount = 0;
    public int level = 1;
    public int max_experience = 0;
    Func<int, bool> cb;
    public Experience(int max, Func<int, bool> _cb) {
    	max_experience = max;
        cb = _cb;
    }
    public void increase(int amt){
    	amount += amt;
    	while(amount >= max_experience){
    		amount -= max_experience;
    		level++;
            cb(level);
    		max_experience = (int)(max_experience * 1.4);
    	}
    }
}
