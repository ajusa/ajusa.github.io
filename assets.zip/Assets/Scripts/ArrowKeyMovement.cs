﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Events;
using UnityEngine.EventSystems;
public class ArrowKeyMovement : MonoBehaviour {
    // Start is called before the first frame update
    public GameObject menu;
    Rigidbody2D rb;
    Monster m;
    Subscription<SwitchEvent> sub;
    void Awake() {
        sub = EventBus.Subscribe<SwitchEvent>(_switch_monster);
    }
    // Update is called once per frame
    void Update() {
        if(!GameController.instance.paused) {
            if(rb != null) rb.velocity = GetInput() * Mathf.Min(m.e.s.speed, 6f);
            if (m != null && Input.GetMouseButtonDown(0)) {
                if(EventSystem.current.IsPointerOverGameObject()) return;
                Vector3 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                pos.z = 0; //camera is postioned below the scene
                GameController.instance.attacked = true;
                m.Attack(pos);
            }
            if (Input.GetKeyDown(KeyCode.M)) {
                menu.SetActive(true);
            }
        }
    }
    Vector2 GetInput() {
        float h_input = Input.GetAxisRaw("Horizontal");
        float v_input = Input.GetAxisRaw("Vertical");
        return new Vector2(h_input, v_input).normalized;
    }

    void _switch_monster(SwitchEvent s) {
        rb = s.g.GetComponent<Rigidbody2D>();
        m = s.g.GetComponent<Monster>();
    }

}
