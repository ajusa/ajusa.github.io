﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadMenu : MonoBehaviour {
    public GameObject monster_ui;
    void Start() {
        for(int i = 0; i < MonsterList.monsters.Length; i++) {
            GameObject el = Instantiate(monster_ui, transform);
            el.GetComponent<CreateMonster>().e = MonsterList.monsters[i];
        }
    }
    void Update(){
    	if(Input.GetKeyDown(KeyCode.X)){ //escape is broken on my laptop
    		gameObject.SetActive(false);
    		GameController.instance.paused = false;
    	}
    }

    void OnEnable()
    {
        GameController.instance.paused = true;
    }
}
