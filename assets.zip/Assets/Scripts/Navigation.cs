﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class Navigation : MonoBehaviour,
    IPointerClickHandler,
    IPointerEnterHandler,
    IPointerExitHandler {
    Text t;
    Image bg;
    Color orig;
    public GameObject menu;
    public PlaceMonster pm;
    // Start is called before the first frame update
    void Awake() {
        bg = transform.parent.gameObject.GetComponent<Image>();
        orig = bg.color;
        orig.a = .2f;
        bg.color = orig;
        t = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update() {
        if(GameController.instance.paused) {
            t.text = "Go Back";
        } else {
            t.text = "Menu";
        }
    }
    public void OnPointerEnter(PointerEventData eventData) {
        Color c = orig;
        c.a = .6f;
        bg.color = c;
    }
    public void OnPointerClick(PointerEventData eventData) {
        if(GameController.instance.paused) {
            if(pm.is_placing) {
                pm.TurnOff();
            } else {
            	menu.SetActive(false);
            	GameController.instance.paused = false;
            }
        } else {
        	menu.SetActive(true);
        	GameController.instance.opened_menu = true;
        	GameController.instance.paused = true;
        }
    }
    public void OnPointerExit(PointerEventData eventData) {
        bg.color = orig;
    }
}
