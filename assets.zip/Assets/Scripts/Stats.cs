﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public enum TYPE {Staff, Sword};
[Serializable]
public class Stats {
    public int strength = 1; //physical damage
    public int magic = 1; //magical damage
    public int luck = 1; //drops + crits
    public int speed = 1; //movement+ dodging?
    public int defense = 1; //blocks damage taken, both magical and physical
    public int vitality = 1; //affects maximum health and regeneration
    public int dexterity = 1; //attack speed
    public float range = 4f; //how far they can "see"
    public string title;
    public string description;
    public string sprite;
    public Experience exp;
    public TYPE type;
    public Stats() {
        exp = new Experience(10, LevelUp);
    }
    public bool LevelUp(int level) {
        strength++;
        magic++;
        luck++;
        speed++;
        defense++;
        vitality++;
        dexterity++;
        return true;
    }
    public int worth() {
        return strength + magic + luck + speed + defense + vitality;
    }
    public override string ToString() {
        return $"Level: {exp.level}\nEXP: {exp.amount} / {exp.max_experience}\nSTR: {strength}\nMAG: {magic}\nLCK: {luck}\nSPD: {speed}\nDEF: {defense}\nVIT: {vitality}\nDEX: {dexterity}";
    }
}
