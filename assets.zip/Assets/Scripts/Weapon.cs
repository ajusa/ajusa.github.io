using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{
	public Stats s;
    // Start is called before the first frame update
    public virtual void Attack(Vector3 direction){
    	//override in child class please
    }
}
