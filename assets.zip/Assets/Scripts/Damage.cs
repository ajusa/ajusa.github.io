﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damage : MonoBehaviour {
    public float amount = 1f;
    public bool is_projectile = false;
    void Start() {
        Invoke("KYS", 2f);
    }
    void KYS() {
        if(is_projectile) Destroy(gameObject);
    }
    void OnCollisionEnter2D(Collision2D c) {
        Health h = c.gameObject.GetComponent<Health>();
        if(h != null) {
            h.damage(amount, gameObject);
        }
        KYS();
    }
}
