﻿using UnityEngine;
using UnityEngine.EventSystems;
public class CameraDrag : MonoBehaviour {
    Vector3 dragOrigin;
    Camera cam;
    Vector3 prevWorldPos, curWorldPos, worldPosDelta;

    void Awake() {
        cam = GetComponent<Camera>();
    }
    void Update() {
        if(!GameController.instance.paused) return;
        if(EventSystem.current.IsPointerOverGameObject()) return;
        if (Input.GetMouseButtonDown(0)) {
            prevWorldPos = cam.ScreenToWorldPoint(Input.mousePosition);
        }
        if (Input.GetMouseButton(0)) {
            //Gets the delta of the worldPos and mousePos
            worldPosDelta = cam.ScreenToWorldPoint(Input.mousePosition) - prevWorldPos;
            cam.transform.position = new Vector3(cam.transform.position.x - worldPosDelta.x, cam.transform.position.y - worldPosDelta.y, cam.transform.position.z);
            //Set previous variables to current state for use in next frame
            prevWorldPos = cam.ScreenToWorldPoint(Input.mousePosition);
        }
    }
}