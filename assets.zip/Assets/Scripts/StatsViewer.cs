﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class StatsViewer : MonoBehaviour {
    private Stats focus;
    Subscription<FocusEvent> sub;
    Text t;
    // Start is called before the first frame update
    void Awake() {
        sub = EventBus.Subscribe<FocusEvent>(_focus_change);
        t = transform.Find("Text").gameObject.GetComponent<Text>();
        gameObject.SetActive(false);
        //gameObject.GetComponent<Image>().enabled = false;
    }

    // Update is called once per frame
    void Update() {
        if(focus != null) t.text = focus.ToString();
        else t.text = "";
    }
    void _focus_change(FocusEvent f) {
        gameObject.SetActive(true);
        if(f.s == null) gameObject.SetActive(false);
        focus = f.s;
    }
}
