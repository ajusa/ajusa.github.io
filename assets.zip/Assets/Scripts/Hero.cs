﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Hero : BasicEntity {
    Rigidbody2D rb;
    List<Vector3> Waypoints1 = new List<Vector3>() {
        new Vector3(-22.5f, 17.5f, 0f),
            new Vector3(-0f, 17f, 0f),
            Vector3.zero
    };
    List<Vector3> Waypoints2 = new List<Vector3>() {
        new Vector3(25.5f, -17.75f, 0f),
            new Vector3(-0f, -17f, 0f),
            Vector3.zero
    };
    public List<Vector3> waypoints = new List<Vector3>();
    int index = 0;
    AIState state = AIState.Moving;
    Health h;
    int layerMask = 1 << 8; //see a monster
    public void Awake() {
        rb = GetComponent<Rigidbody2D>();
        h = GetComponent<Health>();
        h.OnInvincibleStart.AddListener(Invincible);
        h.OnInvincibleEnd.AddListener(NotInvincible);
        h.OnDeath.AddListener(Death);
        InvokeRepeating("IncreaseDP", 1.0f, 1.0f);
    }
    void Invincible() {
        gameObject.layer = 11;
    }
    void NotInvincible() {
        gameObject.layer = 9;
    }
    void Death() {
        GameController.instance.DP += e.cost() / 2;
    }
    void IncreaseDP() {
        GameController.instance.DP++; //increase by 1 each second they are in the dungeon
    }
    void Start() {
        base.Start();
    }
    public void IsLeft(bool b){
        waypoints = b ? Waypoints1 : Waypoints2;
    }
    // Update is called once per frame
    void Update() {
        Collider2D c = Physics2D.OverlapCircle(transform.position, 3f, layerMask);
        if(c != null) {
            if(c.gameObject.GetComponent<Monster>() != null) {
                Transform target = c.gameObject.GetComponent<Transform>();
                if(e.equip.Count > 0 && Vector3.Distance(transform.position, target.position) < e.equip[0].range)
                    Attack(target.position);
                else rb.velocity = (target.position - transform.position).normalized * e.s.speed;
            }
        } else {
            Vector3 dist = waypoints[index] - transform.position;
            if(dist.magnitude < .5f && waypoints.Count > index + 1) index++;
            rb.velocity = dist.normalized * e.s.speed;
        }
    }
}
