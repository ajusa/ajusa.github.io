using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class MonsterList {

    public static Entity dungeon_lord = create_dungeon_lord();
    public static Entity skeleton = create_skeleton();
    public static Entity[] monsters = {
        create_skeleton(),
        create_sword_skeleton(),
        create_sword_ogre(),
        create_archmage_skeleton(),
        create_archmage_ogre()
    };
    static Entity create_dungeon_lord() {
        Entity e = new Entity();
        e.s.speed = 4;
        e.s.vitality = 5;
        e.s.magic = 4;
        e.s.sprite = "newchars_585";
        Stats staff = new Stats();
        staff.type = TYPE.Staff;
        staff.sprite = "newchars_36"; //newchars_364 is the sword
        e.equip.Add(staff);
        return e;
    }
    static Entity create_skeleton() {
        Entity e = new Entity();
        e.s.speed = 3;
        e.s.magic = 2;
        e.s.sprite = "newchars_414";
        e.s.title = "Mage Skeleton";
        Stats staff = new Stats();
        staff.type = TYPE.Staff;
        staff.sprite = "newchars_36"; //newchars_364 is the sword
        e.equip.Add(staff);
        return e;
    }
    static Entity create_sword_skeleton() {
        Entity e = new Entity();
        e.s.speed = 3;
        e.s.magic = 2;
        e.s.sprite = "newchars_414";
        e.s.title = "Swordsman Skeleton";
        Stats sword = new Stats();
        sword.range = 1.2f;
        sword.type = TYPE.Sword;
        sword.sprite = "newchars_364"; //newchars_364 is the sword
        e.equip.Add(sword);
        return e;
    }
    static Entity create_archmage_skeleton() {
        Entity e = new Entity();
        e.s.speed = 3;
        e.s.magic = 5;
        e.s.vitality = 2;
        e.s.sprite = "newchars_414";
        e.s.title = "Archmage Skeleton";
        Stats staff = new Stats();
        staff.type = TYPE.Staff;
        staff.sprite = "newchars_36"; //newchars_364 is the sword
        e.equip.Add(staff);
        return e;
    }
    static Entity create_sword_ogre() {
        Entity e = new Entity();
        e.s.speed = 2;
        e.s.strength = 5;
        e.s.defense = 2;
        e.s.vitality = 6;
        e.s.sprite = "newchars_457";
        e.s.title = "Swordsman Zombie";
        Stats sword = new Stats();
        sword.range = 1.3f;
        sword.type = TYPE.Sword;
        sword.sprite = "newchars_364"; //newchars_364 is the sword
        e.equip.Add(sword);
        return e;
    }
    static Entity create_archmage_ogre() {
        Entity e = new Entity();
        e.s.speed = 2;
        e.s.magic = 4;
        e.s.vitality = 6;
        e.s.sprite = "newchars_457";
        e.s.title = "Archmage Zombie";
        Stats staff = new Stats();
        staff.type = TYPE.Staff;
        staff.sprite = "newchars_36"; //newchars_364 is the sword
        e.equip.Add(staff);
        return e;
    }

}