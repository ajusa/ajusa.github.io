using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.EventSystems;
public class PlaceMonster : MonoBehaviour {
    public bool is_placing = false;
    public GameObject monster_prefab;
    public GameObject menu;
    public Tilemap floor;
    public GameObject help;
    Subscription<SpawnEvent> sub;
    public Entity to_place;
    void Awake() {
        sub = EventBus.Subscribe<SpawnEvent>(_create_monster);
    }
    void Update() {
        if(is_placing) {
            if(EventSystem.current.IsPointerOverGameObject()) return;
            if (Input.GetMouseButtonDown(1)) {
                Vector3 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                pos.z = 0f;
                if(floor.localBounds.Contains(pos)) {
                    if(GameController.instance.DP >= to_place.cost()) GameController.instance.DP -= to_place.cost();
                    else return;
                    GameObject g = Instantiate(monster_prefab, pos, Quaternion.identity);
                    g.GetComponent<Monster>().e = to_place.DeepClone();
                    GameController.instance.summoned_monster = true;
                }
            }
        }
    }
    public void TurnOff() {
        is_placing = false;
        to_place = null;
        menu.SetActive(true);
        help.SetActive(false);
    }
    void _create_monster(SpawnEvent s) {
        to_place = s.e;
        is_placing = true;
        help.SetActive(true);
    }

}