using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sword : Weapon {
    public GameObject projectile;
    GameObject p;
    Quaternion goal_rotation;
    public void Update() {
        if(p != null) {
        	p.transform.localPosition = Vector3.zero;
        	p.transform.position = transform.position;
            Quaternion next = Quaternion.Lerp(p.transform.rotation, goal_rotation, .2f);
            if(Mathf.Abs(Quaternion.Angle(next, p.transform.rotation)) < .1f) {
                Destroy(p);
                p = null;
            } else p.transform.rotation = next;
        }
    }
    // Start is called before the first frame update
    public void Attack(Vector3 direction) {
        p = Instantiate(projectile, transform);
        p.transform.parent = transform;
        foreach (Transform child in p.transform) {
            GameObject sword = child.gameObject;
            p.transform.localScale = new Vector3(p.transform.localScale.x, s.range, p.transform.localScale.z);
            sword.GetComponent<Damage>().amount = transform.parent.GetComponent<BasicEntity>().e.s.strength;
            Vector3 diff = direction - p.transform.position;
            float rot = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;
            p.transform.rotation = Quaternion.Euler(0.0f, 0.0f, rot + 90 + 50);
            goal_rotation = Quaternion.Euler(0.0f, 0.0f, rot + 90 - 50);
            child.gameObject.layer = transform.parent.gameObject.layer;
        }
    }
}
