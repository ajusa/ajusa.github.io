﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.Events;
public class Health : MonoBehaviour {
    public float max_health = 6;
    public float health = 6;
    public float hitstun_time = .1f;
    public float hitstun_speed = 4f;
    public bool is_invincible = false;
    public float time_left = -1f;
    Color original;
    Material mat;
    Rigidbody2D rb;
    BasicEntity b;
    Vector2 direction = Vector2.zero;
    public UnityEngine.Events.UnityEvent OnDeath = new UnityEvent();
    public UnityEngine.Events.UnityEvent OnInvincibleStart = new UnityEvent();
    public UnityEngine.Events.UnityEvent OnInvincibleEnd = new UnityEvent();
    void Awake() {
        b = GetComponent<BasicEntity>();
        mat = GetComponent<Renderer>().material;
        rb = GetComponent<Rigidbody2D>();
        health = max_health;
        original = mat.color;
    }
    void Start() {
        max_health = b.e.s.vitality + 5;
        health = max_health;
        InvokeRepeating("regen", 2f, 2f);
    }
    void LateUpdate() {
        if(time_left > 0.0f) {
            rb.velocity = direction * hitstun_speed;
            time_left -= Time.deltaTime;
            mat.color = Color.red;
        }
        if(mat.color != original && ((Vector4)(mat.color - original)).magnitude < .2) {
            mat.color = original;
            is_invincible = false;
            //OnInvincibleEnd.Invoke();
        }
        mat.color = Color.Lerp(mat.color, original, 0.04f);
    }
    void regen() {
        heal((float)b.e.s.vitality / 4);
    }
    // Start is called before the first frame update
    public void heal(float amt) {
        health = Mathf.Min(health + amt, max_health);
    }
    public void damage(float amt, GameObject cause) {
        amt -= (b.e.s.defense/4);
        health -= Mathf.Max(amt, 1);
        if(health <= 0) {
            GameObject g = find_cause(cause);
            if(g != null) {
                BasicEntity other = g.GetComponent<BasicEntity>();
                other.e.s.exp.increase(b.e.cost());
            }
            OnDeath.Invoke();
            Destroy(gameObject);
        }
        direction = ((Vector3)rb.position - cause.transform.position).normalized;
        time_left = hitstun_time;
        //OnInvincibleStart.Invoke();
        is_invincible = true;
        //}
        //if(health <= 0) //death
    }
    GameObject find_cause(GameObject g) {
        Transform t = g.transform;
        while (t.parent != null) {
            if (t.parent.gameObject.GetComponent<BasicEntity>() != null) {
                return t.parent.gameObject;
            }
            t = t.parent.transform;
        }
        return null;
    }
}
