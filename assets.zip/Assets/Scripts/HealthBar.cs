﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthBar : MonoBehaviour {
    public Health focus;
    Transform bar;
    Transform damage_bar;
    // Start is called before the first frame update
    void Start() {
        bar = transform.Find("Bar");
        damage_bar = transform.Find("Damage");
    }

    // Update is called once per frame
    void Update() {
        Vector3 target = new Vector3((float)focus.health / focus.max_health, bar.localScale.y, bar.localScale.z);
        bar.localScale = Vector3.Lerp(bar.localScale, target, .1f);
        if(Mathf.Abs(bar.localScale.x - target.x) < .05){ //hide damage bar/set the scale to be the same
            damage_bar.localScale = bar.localScale;
        }
        if(Mathf.Approximately(bar.localScale.x, 1f)) { //if health is full, go ahead and hide the bar after a bit
            foreach (Transform child in transform) child.gameObject.SetActive(false);
        } else {
            foreach (Transform child in transform) child.gameObject.SetActive(true);
        }
    }
}
