﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.SceneManagement;
public class GameController : MonoBehaviour {
    public static GameController instance;
    public Dictionary<string, Sprite> Sprites;
    public GameObject hero_prefab;
    public GameObject lose_screen;
    public GameObject lord;
    public int DP = 50;
    public Text amt;
    public bool paused = false;
    public bool opened_menu = false;
    public bool summoned_monster = false;
    public bool attacked = false;
    public bool possesed = false;
    bool is_tutorial = true;
    public GameObject tut_opened_menu;
    public GameObject tut_summoned_monster;
    public GameObject tut_attacked;
    public GameObject tut_possesed;
    public GameObject tut_last;
    int hero = 0;
    void Awake() {
        if(Sprites == null) Sprites = load_sprites();
        if (instance == null) {
            instance = this;
        } else if (instance != this) {
            Destroy(gameObject);
        }
    }

    // Update is called once per frame
    void Update() {
        amt.text = $"DP: {DP}";
        if (lose_screen.activeSelf && Input.GetMouseButton(0)) {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
        if(paused) Time.timeScale = 0f;
        else Time.timeScale = 1f;
        if(is_tutorial) {
            if(opened_menu) tut_opened_menu.SetActive(false);
            if(summoned_monster) tut_summoned_monster.SetActive(false);
            if(possesed) tut_possesed.SetActive(false);
            if(attacked) tut_attacked.SetActive(false);
            if(opened_menu && summoned_monster && possesed && attacked) {
                Invoke("SpawnHero", 1f);
                is_tutorial = false;
            }
        }
    }
    static Dictionary<string, Sprite> load_sprites() {
        Dictionary<string, Sprite> d = new Dictionary<string, Sprite>();
        Sprite[] sprites = Resources.LoadAll<Sprite>("newchars");
        foreach (Sprite s in sprites) {
            d.Add(s.name, s);
        }
        return d;
    }
    void SpawnHero() {
        tut_last.SetActive(false);
        hero++;
        GameObject g;
        if (Random.value < .5) {
            g = Instantiate(hero_prefab, new Vector3(-22.5f + Random.Range(-.5f, .5f), -3.5f, 0), Quaternion.identity);
            g.GetComponent<Hero>().IsLeft(true);
        } else {
            g = Instantiate(hero_prefab, new Vector3(25.5f + Random.Range(-.5f, .5f), 8f, 0), Quaternion.identity);
            g.GetComponent<Hero>().IsLeft(false);
        }
        if (Random.value < .5) {
            g.GetComponent<Hero>().e = HeroList.create_mage_fighter(hero);
        } else {
            g.GetComponent<Hero>().e = HeroList.create_sword_fighter(hero);
        }
        float initial = 6f - (float)hero / 4;
        if(initial < 3f) initial = 3f;
        Invoke("SpawnHero", Random.Range(initial - 1f, initial)); //slowly decrease this?
    }
    public void Loss(string reason) {
        lose_screen.SetActive(true);
        paused = true; //pause the game
        lose_screen.transform.Find("Text").gameObject.GetComponent<Text>().text = reason + " Click to play again.";
    }
}

public static class ExtensionMethods {
    // Deep clone
    public static T DeepClone<T>(this T a) {
        using (MemoryStream stream = new MemoryStream()) {
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, a);
            stream.Position = 0;
            return (T) formatter.Deserialize(stream);
        }
    }
}
