﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
enum AIState {
    Moving,
    Waiting,
    Attacking
}
public class Monster : BasicEntity {
    public bool auton = true;
    public bool is_lord = false;
    public Vector3 placement; //original position
    public Transform target;
    float time_since_enemy = 0f;
    Rigidbody2D rb;
    Health h;
    AIState state = AIState.Waiting;
    int layerMask = 1 << 9; //see a hero
    public void Awake() {
        rb = GetComponent<Rigidbody2D>();
        placement = transform.position;
        h = GetComponent<Health>();
        if(is_lord) {
            e = MonsterList.dungeon_lord.DeepClone();
            EventBus.Publish<SwitchEvent>(new SwitchEvent(gameObject));
        }
        h.OnInvincibleStart.AddListener(Invincible);
        h.OnInvincibleEnd.AddListener(NotInvincible);
        h.OnDeath.AddListener(Death);
    }
    void Invincible() {
        gameObject.layer = 10;
    }
    void NotInvincible() {
        gameObject.layer = 8;
    }
    void Death() {
        if(!auton) EventBus.Publish<SwitchEvent>(new SwitchEvent(GameController.instance.lord));
        if(is_lord) {
            GameController.instance.Loss("Dungeon Lord was killed!");
        }
    }
    void Start() {
        base.Start();
        if(is_lord) Focus();
    }
    // Update is called once per frame
    void Update() {
        if(auton) {
            Collider2D c = Physics2D.OverlapCircle(transform.position, e.s.range, layerMask);
            if(c != null) {
                if(c.gameObject.GetComponent<Hero>() != null) {
                    target = c.gameObject.GetComponent<Transform>();
                    time_since_enemy = 0;
                    if(e.equip.Count > 0 && Vector3.Distance(transform.position, target.position) < e.equip[0].range)
                        Attack(target.position);
                    else if(!is_lord) rb.velocity = (target.position - transform.position).normalized * e.s.speed;
                }
            } else if(!is_lord) { //teleport back to original position
                time_since_enemy += Time.deltaTime;
                rb.velocity = Vector3.zero;
                GoBack();
            }
        }
    }
    void GoBack() {
        if(time_since_enemy > 3f) transform.position = placement; //add some teleport effect?
    }
    void Focus() {
        EventBus.Publish<SwitchEvent>(new SwitchEvent(gameObject));
        auton = false; //disable the AI
        state = AIState.Moving;
    }
    void OnMouseOver () {
        if(GameController.instance.paused) return;
        if(Input.GetMouseButtonDown(1)) {
            Focus();
            GameController.instance.possesed = true;
        }
    }


}
public class SwitchEvent {
    public GameObject g;
    public SwitchEvent(GameObject _g) {
        g = _g;
    }
}
