﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
public class CreateMonster : MonoBehaviour,
    IPointerClickHandler,
    IPointerEnterHandler,
    IPointerExitHandler {
    // Start is called before the first frame update
    public Entity e; //entity to display
    public Text title;
    public Image avatar;
    public GameObject monster_prefab;
    public Button top;
    public Button bottom;
    Image bg;
    Color orig;
    void Start() {
        bg = GetComponent<Image>();
        orig = bg.color;
        orig.a = .2f;
        bg.color = orig;
        title = transform.Find("Text").gameObject.GetComponent<Text>();
        avatar = transform.Find("Image").gameObject.GetComponent<Image>();
        avatar.sprite = GameController.instance.Sprites[e.s.sprite];
        title.text = $"{e.s.title} | {e.cost()} DP";
    }

    public void OnPointerEnter(PointerEventData eventData) {
        Color c = orig;
        c.a = .6f;
        GetComponent<Image>().color = c;
        EventBus.Publish<FocusEvent>(new FocusEvent(e.s));
    }
    public void OnPointerClick(PointerEventData eventData) {
        EventBus.Publish<SpawnEvent>(new SpawnEvent(e));
        transform.parent.gameObject.SetActive(false);
    }
    public void OnPointerExit(PointerEventData eventData) {
        bg.color = orig;
        EventBus.Publish<FocusEvent>(new FocusEvent(null));
    }
}

public class SpawnEvent {
    public Entity e;
    public SpawnEvent(Entity _e) {
        e = _e;
    }
}