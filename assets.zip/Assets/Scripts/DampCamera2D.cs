﻿using UnityEngine;
using System.Collections;

public class DampCamera2D : MonoBehaviour {
    public Transform target;
    public float smoothTime = 0.3F;
    private Vector3 velocity = Vector3.zero;
    Subscription<SwitchEvent> sub;
    void Awake() {
        sub = EventBus.Subscribe<SwitchEvent>(_switch_monster);
    }
    void Update() {
        if(target != null) {
            // Define a target position above and behind the target transform
            Vector3 targetPosition = target.TransformPoint(new Vector3(0, 0, -10));
            // Smoothly move the camera towards that target position
            transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
        }
    }
    void _switch_monster(SwitchEvent s) {
        if(target != null) target.GetComponent<Monster>().auton = true;
        target = s.g.GetComponent<Transform>();
        target.GetComponent<Monster>().auton = false;
    }

    public static Vector3 Round(Vector3 vector3) {
        float multiplier = 32;
        return new Vector3(
                   Mathf.Round(vector3.x * multiplier) / multiplier,
                   Mathf.Round(vector3.y * multiplier) / multiplier,
                   Mathf.Round(vector3.z * multiplier) / multiplier);
    }
}