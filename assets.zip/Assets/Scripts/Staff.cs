﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Staff : Weapon {
    public GameObject projectile;
    
    // Start is called before the first frame update
    public void Attack(Vector3 direction) {
        GameObject bolt = Instantiate(projectile, transform);
        bolt.layer = transform.parent.gameObject.layer;
        bolt.GetComponent<Damage>().amount = transform.parent.GetComponent<BasicEntity>().e.s.magic;
        Vector3 path = 5f * (direction - transform.position).normalized;
        bolt.GetComponent<Rigidbody2D>().velocity = path;
    }
}
