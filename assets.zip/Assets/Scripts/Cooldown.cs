﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cooldown : MonoBehaviour {
    public BasicEntity focus;
    Transform bar;
    // Start is called before the first frame update
    void Start() {
        bar = transform.Find("Bar");
        foreach (Transform child in transform) child.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update() {
        if(Mathf.Approximately(Time.time, 0f) || focus.last_attack == 0f || focus.next_attack == 0f) return;
        Vector3 target = new Vector3((Time.time - focus.last_attack) / (focus.next_attack - focus.last_attack),
        	bar.localScale.y, bar.localScale.z);
        bar.localScale = target; //Vector3.Lerp(bar.localScale, target, .1f);
        if(target.x > 1f || Mathf.Approximately(bar.localScale.x, 1f)) { //if health is full, go ahead and hide the bar after a bit
            foreach (Transform child in transform) child.gameObject.SetActive(false);
        } else {
            foreach (Transform child in transform) child.gameObject.SetActive(true);
        }
    }
}
