﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.EventSystems;
public class BasicEntity : MonoBehaviour {
    public GameObject w;
    public float next_attack = 0f;
    public float last_attack = 0f;
    public Entity e;
    public void Start() {
        if(e == null) e = new Entity(); //should be set
        foreach(Stats s in e.equip) {
            if(s.type == TYPE.Staff || s.type == TYPE.Sword){
                w = transform.Find(s.type.ToString()).gameObject;
                w.SetActive(true);
                w.GetComponent<Weapon>().s = s;
                w.GetComponent<SpriteRenderer>().sprite = GameController.instance.Sprites[s.sprite];
            }
        }
        GetComponent<SpriteRenderer>().sprite = GameController.instance.Sprites[e.s.sprite];
    }
    public void Attack(Vector3 direction) {
        if (next_attack <= Time.time && w != null) {
            w.SendMessage("Attack", direction);
            last_attack = Time.time;
            next_attack = Time.time + 2 / (float)e.s.dexterity;
        }
    }
    public void OnMouseEnter() {
        if(EventSystem.current.IsPointerOverGameObject()) return;
        EventBus.Publish<FocusEvent>(new FocusEvent(e.s));
    }
    public void OnMouseExit() {
        if(EventSystem.current.IsPointerOverGameObject()) return;
        EventBus.Publish<FocusEvent>(new FocusEvent(null));
    }
    public void OnCollisionEnter2D(Collision2D c) {
        Health h = c.gameObject.GetComponent<Health>();
        if(h != null) {
            h.damage((float)e.s.strength / 2, gameObject);
        }
    }
}

public class FocusEvent {
    public Stats s;
    public FocusEvent(Stats _s) {
        s = _s;
    }
}

