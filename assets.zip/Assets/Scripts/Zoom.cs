using UnityEngine;
using System.Collections;
//Modified from https://answers.unity.com/questions/827105/smooth-2d-camera-zoom.html
public class Zoom : MonoBehaviour {

    public float zoomSpeed = 1;
    public float target;
    public float smoothSpeed = 2.0f;
    public float minOrtho = 3.0f;
    public float maxOrtho = 20.0f;

    void Start() {
        target = Camera.main.orthographicSize;
    }

    void Update () {
        float scroll = Input.GetAxis ("Mouse ScrollWheel");
        if (scroll != 0.0f) {
            target -= scroll * zoomSpeed;
            target = Mathf.Clamp (target, minOrtho, maxOrtho);
        }
        Camera.main.orthographicSize = Mathf.MoveTowards (Camera.main.orthographicSize, target, smoothSpeed * Time.deltaTime);
    }
}